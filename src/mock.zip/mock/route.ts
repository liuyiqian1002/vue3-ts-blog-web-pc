// @ts-ignore
import {Result} from "./_utils"
import {MockMethod} from "vite-plugin-mock"
// import Mock from "mockjs";
import {Document, Menu as IconMenu, Location, Setting, Edit, User} from '@element-plus/icons-vue'

export default [
    {
        url: '/api/getMenu', // 注意，这里只能是string格式
        method: 'get',
        response: () => {
            Result.data = [
                {
                    name: 'Homes', level: 1,component: 'layout', path: '/', children: [
                        {parentId: 'Homes',name: 'Home', title: '首页',  meta: {title: '首页', name: 'Home', icon: 'iconshouye', affix: true}, path: '/',}
                    ]
                },
                {
                    name: 'Users', level: 1,meta: {title: '用户', icon: 'iconziyuan111'},  component: 'layout', path: '/users', children: [
                        {parentId: 'Users',name: 'User', meta: {title: '用户', name: 'Users', icon: 'iconziyuan111'}, path: '/users',},
                        {parentId: 'Users',name: 'UserDetail', meta: {title: '用户详情', name: 'UserDetail', icon: 'iconshujuquanxian'}, path: '/users/userDetails',}
                    ]
                },
                {
                    name: 'Posts', level: 1, title: 'demo', component: 'layout', path: '/demo', children: [
                        {parentId: 'Posts',name: 'Post', meta: {title: 'demo', name: 'Posts', icon: 'iconqudaoguanli'}, path: '/demo',}
                    ]
                },
                {

                    name: 'Elements', level: 1, component: 'layout',
                    meta: {title: 'ElementPlus', name: 'ECharts', icon: 'iconzhexiantu'},
                    path: '/element', children: [
                        {parentId: 'Elements',name: 'Element', meta: {title: 'ElementPlus', name: 'UI Element', icon: 'iconkaifangpingtai'}, path: '/element'},
                        { parentId: 'Elements', name: 'table', level: 2, meta: {title: 'ElementTable', name: 'ECharts', icon: 'iconzhexiantu'}, path: '/element/table', },
                    ]
                },
                {
                    name: 'forms', level: 1, component: 'layout', path: '/forms', children: [
                        {parentId: 'forms',name: 'form', meta: {title: 'form-基础渲染', name: 'form-基础渲染', icon: 'iconkaifangpingtai'}, path: '/form',}
                    ]
                },

            ]
            return Result;
        },
    },
]; // 定义数据格式

