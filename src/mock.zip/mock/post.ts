import Mock from 'mockjs'
export default [
  {
    url: '/api/posts', // 注意，这里只能是string格式
    method: 'get',
    response: () => {
      return {
        code: 200,
        message: 'ok',
        response: () => {
          //批量模拟随机数
          let data = [];
          for (let i = 1; i < 301; i++) {
            let obj = Mock.mock({
              'rows|1-100': 100,
            });
            data.push(obj.rows);
          }
          return data;
        },
      }
    },
  },
]
