/*
 * @Description:
 * @Version:
 * @Autor: LiChuang
 * @Date: 2022-06-29 16:22:49
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2022-06-29 16:33:09
 */
// @ts-ignore
import { Result } from "./_utils"
import { MockMethod } from "vite-plugin-mock"
import Mock from "mockjs";

export default [
    {
        url: '/api/login', // 注意，这里只能是string格式
        method: 'get',
        response: () => {
            Result.data = {
                id: "1",
                username: "test",
                token: 'gfkdjhwifjsdlnfsdnnjfjdsj',
                avatar: "https://image-1300566513.cos.ap-guangzhou.myqcloud.com/upload/images/5a9f48118166308daba8b6da7e466aab.jpg"
            }
            return Result;
        },
    },
    {
        url: '/api/posts', // 注意，这里只能是string格式
        method: 'get',
        response: () => {
            return {
                code: 200,
                message: 'ok',
                response: () => {
                    //批量模拟随机数
                    let data = [];
                    for (let i = 1; i < 301; i++) {
                        let obj = Mock.mock({
                            'rows|1-100': 100,
                        });
                        data.push(obj.rows);
                    }
                    console.log(data);
                    return data;
                },
            }
        },
    },
] as MockMethod[]; // 定义数据格式
